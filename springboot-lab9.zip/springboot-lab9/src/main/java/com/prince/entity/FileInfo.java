package com.prince.entity;

public class FileInfo {
	public String filename;
	public String path;
	public long uploadedbytes;
	public long filesize;
	
}
