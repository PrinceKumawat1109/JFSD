package com.prince;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootLab9ApplicationTests {

	@Test
	void contextLoads() {
	}

}
