package com.klu.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab8JfsdApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lab8JfsdApplication.class, args);
	}

}
